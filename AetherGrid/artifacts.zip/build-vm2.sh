#!/usr/bin/env bash
# ==============================================================================
# AetherGrid Infrastructure Deployment Script: VM 2 (Production Core)
# Target: Ubuntu 22.04 / 24.04 LTS (x86_64 / arm64)
# Role: HashiCorp Vault Server, Nomad Cluster Orchestrator & Production Secrets
# ==============================================================================

set -euo pipefail

export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a

HOSTNAME_CORE="aether-core"
DOMAIN_NAME="aethergrid.internal"
INTERNAL_GATEWAY_IP="${INTERNAL_GATEWAY_IP:-10.211.55.10}"

VAULT_ROLE_ID="aether-ci-worker-role"
VAULT_SECRET_ID="3f8b92c1-7d1a-4e55-980b-6a1e3d5c90aa"
VAULT_CLIENT_TOKEN="hvs.aether_ci_pipeline_token_98214"
NOMAD_MGMT_TOKEN="nomad-mgmt-sec-7f9a1c88-e21b-4d92-9011-882194aef102"

FLAG_ROOT_PATH="/root/proof.txt"

CORE_DIR="/opt/aethergrid/core"
VAULT_DIR="/opt/aethergrid/vault"
NOMAD_DIR="/opt/aethergrid/nomad"
LOG_DIR="/var/log/aethergrid"

echo "[*] ============================================================"
echo "[*] Starting AetherGrid VM-2 (Production Core) Deployment"
echo "[*] Timestamp: $(date -u)"
echo "[*] ============================================================"

if [[ $EUID -ne 0 ]]; then
   echo "[-] Root privileges required. Aborting." 1>&2
   exit 1
fi

# ------------------------------------------------------------------------------
# 1. System Packages & Dependencies
# ------------------------------------------------------------------------------
echo "[*] Installing core dependencies and runtime packages..."

if [ -f /etc/needrestart/needrestart.conf ]; then
    sed -i "s/#\$nrconf{restart} = 'i';/\$nrconf{restart} = 'a';/g" /etc/needrestart/needrestart.conf || true
fi

# Ensure reliable DNS resolution for apt packages
rm -f /etc/resolv.conf
cat << EOF > /etc/resolv.conf
nameserver 8.8.8.8
nameserver 1.1.1.1
EOF

apt-get update -y
apt-get install -y --no-install-recommends \
    python3 \
    python3-pip \
    python3-dev \
    python3-venv \
    python3-flask \
    python3-requests \
    python3-yaml \
    gunicorn \
    curl \
    wget \
    git \
    net-tools \
    socat \
    netcat-traditional \
    iptables \
    ufw \
    sqlite3 \
    sudo \
    jq \
    ca-certificates

pip3 install --no-cache-dir --break-system-packages flask requests pyyaml 2>/dev/null || \
pip3 install --no-cache-dir flask requests pyyaml || true

# ------------------------------------------------------------------------------
# 2. Hostname & Network Configuration
# ------------------------------------------------------------------------------
echo "[*] Configuring hostname and internal routing..."

hostnamectl set-hostname "${HOSTNAME_CORE}"

cat << EOF > /etc/hosts
127.0.0.1 localhost
127.0.1.1 ${HOSTNAME_CORE}.${DOMAIN_NAME} ${HOSTNAME_CORE}
127.0.0.1 core.${DOMAIN_NAME} vault.${DOMAIN_NAME} nomad.${DOMAIN_NAME}

${INTERNAL_GATEWAY_IP} aether-gateway portal.${DOMAIN_NAME}

::1     ip6-localhost ip6-loopback
fe00::0 ip6-localnet
ff00::0 ip6-mcastprefix
ff02::1 ip6-allnodes
ff02::2 ip6-allrouters
EOF

# ------------------------------------------------------------------------------
# 3. Directory Structures
# ------------------------------------------------------------------------------
echo "[*] Setting up directory hierarchy..."

mkdir -p "${CORE_DIR}" "${VAULT_DIR}" "${NOMAD_DIR}" "${NOMAD_DIR}/tasks" "${LOG_DIR}"

# ------------------------------------------------------------------------------
# 4. HashiCorp Vault Server Engine (Port 8200)
# ------------------------------------------------------------------------------
echo "[*] Deploying HashiCorp Vault Server Engine..."

cat << 'EOF' > "${VAULT_DIR}/vault_server.py"
#!/usr/bin/env python3
"""
AetherGrid HashiCorp Vault Server Engine
Implements standard Vault REST API v1 for AppRole authentication and KV Secrets Engine.
"""

import os
import sys
import json
import time
from flask import Flask, request, jsonify

app = Flask(__name__)

ROLE_ID = "aether-ci-worker-role"
SECRET_ID = "3f8b92c1-7d1a-4e55-980b-6a1e3d5c90aa"
VALID_CLIENT_TOKEN = "hvs.aether_ci_pipeline_token_98214"
NOMAD_TOKEN = "nomad-mgmt-sec-7f9a1c88-e21b-4d92-9011-882194aef102"

SECRETS_STORE = {
    "orchestrator/nomad-token": {
        "data": {
            "management_token": NOMAD_TOKEN,
            "cluster_addr": "http://nomad.aethergrid.internal:4646",
            "environment": "production-core"
        },
        "metadata": {
            "created_time": "2026-08-23T04:12:00.000Z",
            "version": 1
        }
    },
    "production/database": {
        "data": {
            "db_user": "aether_core_app",
            "db_pass": "P0stgr3s_Pr0d_S3cur3_Vault_88321!",
            "db_name": "aethergrid_prod"
        },
        "metadata": {
            "created_time": "2026-08-23T04:15:00.000Z",
            "version": 1
        }
    }
}

@app.route("/v1/sys/health", methods=["GET"])
def health_check():
    return jsonify({
        "initialized": True,
        "sealed": False,
        "standby": False,
        "performance_standby": False,
        "replication_performance_mode": "disabled",
        "replication_dr_mode": "disabled",
        "server_time_utc": int(time.time()),
        "version": "1.15.2",
        "cluster_name": "aethergrid-vault-cluster",
        "cluster_id": "v-clust-90214a"
    }), 200

@app.route("/v1/auth/approle/login", methods=["POST"])
def approle_login():
    """
    AppRole login endpoint.
    Accepts: { "role_id": "...", "secret_id": "..." }
    """
    data = request.get_json(force=True, silent=True) or {}
    req_role = data.get("role_id")
    req_secret = data.get("secret_id")

    if req_role == ROLE_ID and req_secret == SECRET_ID:
        return jsonify({
            "auth": {
                "client_token": VALID_CLIENT_TOKEN,
                "accessor": "accessor_aether_approle_90214",
                "policies": ["default", "aether-ci-pipeline"],
                "token_policies": ["default", "aether-ci-pipeline"],
                "metadata": {
                    "role_name": "aether-ci-worker-role"
                },
                "lease_duration": 2764800,
                "renewable": True,
                "entity_id": "entity_ci_pipeline_01",
                "token_type": "service",
                "orphan": True
            }
        }), 200
    else:
        return jsonify({
            "errors": ["invalid role_id or secret_id"]
        }), 400

def get_auth_token():
    token = request.headers.get("X-Vault-Token")
    if not token:
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header.split(" ", 1)[1]
    return token

@app.route("/v1/secret/data/<path:path>", methods=["GET"])
@app.route("/v1/kv/data/<path:path>", methods=["GET"])
@app.route("/v1/<path:path>", methods=["GET"])
def read_secret(path):
    token = get_auth_token()
    if token != VALID_CLIENT_TOKEN:
        return jsonify({"errors": ["permission denied: valid X-Vault-Token required"]}), 403

    clean_path = path.replace("secret/data/", "").replace("kv/data/", "").replace("secret/", "").replace("kv/", "")
    
    if clean_path in SECRETS_STORE:
        return jsonify(SECRETS_STORE[clean_path]), 200
    else:
        return jsonify({"errors": [f"path not found: {clean_path}"]}), 404

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8200)
EOF

chmod +x "${VAULT_DIR}/vault_server.py"

# ------------------------------------------------------------------------------
# 5. HashiCorp Nomad Cluster Orchestrator Engine (Port 4646)
# ------------------------------------------------------------------------------
echo "[*] Deploying HashiCorp Nomad Orchestration Engine..."

cat << 'EOF' > "${NOMAD_DIR}/nomad_server.py"
#!/usr/bin/env python3
"""
AetherGrid HashiCorp Nomad Cluster Orchestrator API
Implements Nomad v1 REST API for job management, evaluations, and task dispatching.
"""

import os
import sys
import json
import time
import subprocess
import uuid
from flask import Flask, request, jsonify

app = Flask(__name__)

NOMAD_MGMT_TOKEN = "nomad-mgmt-sec-7f9a1c88-e21b-4d92-9011-882194aef102"
TASKS_DIR = "/opt/aethergrid/nomad/tasks"

def verify_nomad_auth():
    token = request.headers.get("X-Nomad-Token") or request.headers.get("Authorization", "").replace("Bearer ", "")
    return token == NOMAD_MGMT_TOKEN

@app.route("/v1/status/leader", methods=["GET"])
def status_leader():
    return jsonify("127.0.0.1:4647"), 200

@app.route("/v1/status/peers", methods=["GET"])
def status_peers():
    return jsonify(["127.0.0.1:4647"]), 200

@app.route("/v1/jobs", methods=["GET"])
def list_jobs():
    if not verify_nomad_auth():
        return jsonify({"error": "permission denied: valid X-Nomad-Token required"}), 403

    return jsonify([
        {
            "ID": "production-metrics-collector",
            "Name": "production-metrics-collector",
            "Type": "service",
            "Priority": 50,
            "Status": "running",
            "StatusDescription": "Job is healthy",
            "Datacenters": ["dc1"]
        },
        {
            "ID": "aether-core-database-sync",
            "Name": "aether-core-database-sync",
            "Type": "batch",
            "Priority": 60,
            "Status": "running",
            "StatusDescription": "Batch periodic execution",
            "Datacenters": ["dc1"]
        }
    ]), 200

@app.route("/v1/jobs", methods=["POST"])
@app.route("/v1/job/<job_id>", methods=["POST"])
def register_job(job_id=None):
    """
    Submits a Nomad job specification.
    Accepts standard Nomad Job JSON:
    {
        "Job": {
            "ID": "custom-task-01",
            "TaskGroups": [
                {
                    "Name": "core-tasks",
                    "Tasks": [
                        {
                            "Name": "execute-payload",
                            "Driver": "raw_exec",
                            "Config": {
                                "command": "/bin/bash",
                                "args": ["-c", "id > /tmp/out"]
                            }
                        }
                    ]
                }
            ]
        }
    }
    """
    if not verify_nomad_auth():
        return jsonify({"error": "permission denied: valid X-Nomad-Token required"}), 403

    data = request.get_json(force=True, silent=True) or {}
    job_spec = data.get("Job") or data

    job_name = job_spec.get("ID") or job_spec.get("Name") or job_id or f"task-{uuid.uuid4().hex[:8]}"
    eval_id = str(uuid.uuid4())

    # Write task specification to queue
    job_file = os.path.join(TASKS_DIR, f"{job_name}.json")
    with open(job_file, "w") as f:
        json.dump(job_spec, f, indent=2)

    return jsonify({
        "EvalID": eval_id,
        "EvalCreateIndex": 1024,
        "JobModifyIndex": 2048,
        "KnownLeader": True,
        "LastIndex": 2048,
        "Warnings": ""
    }), 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=4646)
EOF

chmod +x "${NOMAD_DIR}/nomad_server.py"

# ------------------------------------------------------------------------------
# 6. Cluster Orchestrator Task Runner & Root Evaluation Daemon
# ------------------------------------------------------------------------------
echo "[*] Deploying AetherGrid Cluster Task Execution Daemon..."

cat << 'EOF' > "${CORE_DIR}/cluster_runner.py"
#!/usr/bin/env python3
"""
AetherGrid Cluster Task Runner Daemon
Monitors submitted Nomad cluster jobs and executes task definitions with host system privileges.
"""

import os
import sys
import json
import time
import subprocess

TASKS_DIR = "/opt/aethergrid/nomad/tasks"
LOG_FILE = "/var/log/aethergrid/cluster_tasks.log"

def process_job(job_file):
    try:
        with open(job_file, "r") as f:
            job_data = json.load(f)

        job_id = job_data.get("ID") or job_data.get("Name") or os.path.basename(job_file)
        
        # Parse TaskGroups and Tasks
        task_groups = job_data.get("TaskGroups", [])
        for group in task_groups:
            tasks = group.get("Tasks", [])
            for task in tasks:
                config = task.get("Config", {})
                command = config.get("command") or config.get("Command")
                args = config.get("args") or config.get("Args") or []
                script = config.get("script") or config.get("Script") or config.get("exec")

                full_cmd = []
                if script:
                    full_cmd = ["/bin/bash", "-c", script]
                elif command:
                    full_cmd = [command] + list(args)

                if full_cmd:
                    with open(LOG_FILE, "a") as log:
                        log.write(f"[{time.ctime()}] Executing Nomad Task for Job '{job_id}': {full_cmd}\n")
                    
                    # Execute task with full root privileges
                    proc = subprocess.run(
                        full_cmd,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        timeout=30,
                        text=True
                    )
                    
                    with open(LOG_FILE, "a") as log:
                        log.write(f"[{time.ctime()}] Job '{job_id}' exited with code {proc.returncode}\n")

        # Clean up completed job definition
        os.remove(job_file)

    except Exception as e:
        with open(LOG_FILE, "a") as log:
            log.write(f"[{time.ctime()}] Error executing job {job_file}: {str(e)}\n")
        try:
            os.remove(job_file)
        except Exception:
            pass

def main():
    os.makedirs(TASKS_DIR, exist_ok=True)
    while True:
        try:
            for fname in os.listdir(TASKS_DIR):
                if fname.endswith(".json"):
                    fpath = os.path.join(TASKS_DIR, fname)
                    process_job(fpath)
        except Exception:
            pass
        time.sleep(2)

if __name__ == "__main__":
    main()
EOF

chmod +x "${CORE_DIR}/cluster_runner.py"

# ------------------------------------------------------------------------------
# 7. System Verification Token Setup
# ------------------------------------------------------------------------------
echo "[*] Initializing system verification token..."

ROOT_FLAG_HASH=$(openssl rand -hex 16)
echo "${ROOT_FLAG_HASH}" > "${FLAG_ROOT_PATH}"
chown root:root "${FLAG_ROOT_PATH}"
chmod 600 "${FLAG_ROOT_PATH}"

echo "[+] System verification token initialized at: ${FLAG_ROOT_PATH}"

# ------------------------------------------------------------------------------
# 8. Systemd Services Configuration
# ------------------------------------------------------------------------------
echo "[*] Configuring and enabling systemd services..."

cat << EOF > /etc/systemd/system/aether-vault.service
[Unit]
Description=AetherGrid HashiCorp Vault Server
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=${VAULT_DIR}
ExecStart=/usr/bin/python3 ${VAULT_DIR}/vault_server.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

cat << EOF > /etc/systemd/system/aether-nomad.service
[Unit]
Description=AetherGrid HashiCorp Nomad Cluster Engine
After=network.target aether-vault.service

[Service]
Type=simple
User=root
WorkingDirectory=${NOMAD_DIR}
ExecStart=/usr/bin/python3 ${NOMAD_DIR}/nomad_server.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

cat << EOF > /etc/systemd/system/aether-cluster-runner.service
[Unit]
Description=AetherGrid Cluster Task Runner Daemon
After=network.target aether-nomad.service

[Service]
Type=simple
User=root
WorkingDirectory=${CORE_DIR}
ExecStart=/usr/bin/python3 ${CORE_DIR}/cluster_runner.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable aether-vault.service
systemctl enable aether-nomad.service
systemctl enable aether-cluster-runner.service

systemctl restart aether-vault.service
systemctl restart aether-nomad.service
systemctl restart aether-cluster-runner.service

# ------------------------------------------------------------------------------
# 9. Post-Build Verification
# ------------------------------------------------------------------------------
echo "[*] Performing deployment verification..."

sleep 3

if curl -s http://127.0.0.1:8200/v1/sys/health | grep -q "aethergrid-vault-cluster"; then
    echo "[+] HashiCorp Vault is operational on port 8200."
else
    echo "[-] WARNING: Vault service check failed."
fi

if curl -s http://127.0.0.1:4646/v1/status/leader | grep -q "4647"; then
    echo "[+] HashiCorp Nomad Orchestrator is operational on port 4646."
else
    echo "[-] WARNING: Nomad service check failed."
fi

if [ -f "${FLAG_ROOT_PATH}" ]; then
    echo "[+] Root flag verified: $(wc -c < ${FLAG_ROOT_PATH}) bytes."
fi

echo "[*] ============================================================"
echo "[*] AetherGrid VM-2 (Production Core) Deployment Completed!"
echo "[*] ============================================================"
exit 0
