#!/usr/bin/env bash
# ==============================================================================
# AetherGrid Infrastructure Deployment Script: VM 1 (Edge CI/CD Gateway)
# Target: Ubuntu 22.04 / 24.04 LTS (x86_64 / arm64)
# Role: Public Entry Point, CI/CD Build Engine, Developer Portal & Pivoting Host
# ==============================================================================

set -euo pipefail

export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a

HOSTNAME_GATEWAY="aether-gateway"
DOMAIN_NAME="aethergrid.internal"
INTERNAL_CORE_IP="${INTERNAL_CORE_IP:-10.211.55.11}"

DEVELOPER_USER="developer"
DEVELOPER_PASS="DevPortal_AutoSync_2024!"

FLAG_USER_PATH="/home/${DEVELOPER_USER}/local.txt"

APP_DIR="/opt/aethergrid/gateway"
CACHE_DIR="/opt/aethergrid/cache"
LOG_DIR="/var/log/aethergrid"

VAULT_ROLE_ID="aether-ci-worker-role"
VAULT_SECRET_ID="3f8b92c1-7d1a-4e55-980b-6a1e3d5c90aa"

echo "[*] ============================================================"
echo "[*] Starting AetherGrid VM-1 (Edge Gateway) Deployment"
echo "[*] Timestamp: $(date -u)"
echo "[*] ============================================================"

if [[ $EUID -ne 0 ]]; then
   echo "[-] Root privileges required. Aborting." 1>&2
   exit 1
fi

# ------------------------------------------------------------------------------
# 1. System Packages & Dependencies
# ------------------------------------------------------------------------------
echo "[*] Installing core dependencies and runtime packages..."

if [ -f /etc/needrestart/needrestart.conf ]; then
    sed -i "s/#\$nrconf{restart} = 'i';/\$nrconf{restart} = 'a';/g" /etc/needrestart/needrestart.conf || true
fi

# Ensure reliable DNS resolution for apt packages
rm -f /etc/resolv.conf
cat << EOF > /etc/resolv.conf
nameserver 8.8.8.8
nameserver 1.1.1.1
EOF

apt-get update -y
apt-get install -y --no-install-recommends \
    python3 \
    python3-pip \
    python3-dev \
    python3-venv \
    python3-flask \
    python3-requests \
    python3-yaml \
    gunicorn \
    curl \
    wget \
    git \
    net-tools \
    socat \
    netcat-traditional \
    iptables \
    ufw \
    sqlite3 \
    sudo \
    jq \
    ca-certificates

pip3 install --no-cache-dir --break-system-packages flask requests pyyaml 2>/dev/null || \
pip3 install --no-cache-dir flask requests pyyaml || true

# ------------------------------------------------------------------------------
# 2. Hostname & Network Configuration
# ------------------------------------------------------------------------------
echo "[*] Configuring hostname and internal routing..."

hostnamectl set-hostname "${HOSTNAME_GATEWAY}"

cat << EOF > /etc/hosts
127.0.0.1 localhost
127.0.1.1 ${HOSTNAME_GATEWAY}.${DOMAIN_NAME} ${HOSTNAME_GATEWAY}
127.0.0.1 portal.${DOMAIN_NAME}

${INTERNAL_CORE_IP} core.${DOMAIN_NAME} vault.${DOMAIN_NAME} nomad.${DOMAIN_NAME}

::1     ip6-localhost ip6-loopback
fe00::0 ip6-localnet
ff00::0 ip6-mcastprefix
ff02::1 ip6-allnodes
ff02::2 ip6-allrouters
EOF

# ------------------------------------------------------------------------------
# 3. User Accounts & File Hierarchy Setup
# ------------------------------------------------------------------------------
echo "[*] Setting up developer accounts and directory structures..."

mkdir -p "${APP_DIR}" "${APP_DIR}/templates" "${CACHE_DIR}" "${LOG_DIR}"

DEVELOPER_CRYPT=$(openssl passwd -6 "${DEVELOPER_PASS}")
if ! id -u "${DEVELOPER_USER}" >/dev/null 2>&1; then
    useradd -m -s /bin/bash -p "${DEVELOPER_CRYPT}" -d "/home/${DEVELOPER_USER}" "${DEVELOPER_USER}"
else
    usermod -p "${DEVELOPER_CRYPT}" -s /bin/bash "${DEVELOPER_USER}"
fi

mkdir -p "/home/${DEVELOPER_USER}/.config/aether"
mkdir -p "/home/${DEVELOPER_USER}/projects"

# ------------------------------------------------------------------------------
# 4. CI/CD Developer Portal & Manifest Pipeline Engine
# ------------------------------------------------------------------------------
echo "[*] Deploying AetherGrid CI/CD Pipeline Gateway Web Application..."

cat << 'EOF' > "${APP_DIR}/gateway_app.py"
#!/usr/bin/env python3
"""
AetherGrid Enterprise CI/CD Pipeline Engine & Developer Workspace Portal
Provides developer pipeline visualization, artifact repositories, and automated webhooks.
"""

import os
import sys
import json
import time
import subprocess
import datetime
from flask import Flask, request, jsonify, render_template_string, redirect, session, url_for

app = Flask(__name__)
app.secret_key = "A3th3r_Gr1d_S3cur3_Sess10n_K3y_88194!#@"

PIPELINE_HISTORY = [
    {
        "id": "PIPE-9021",
        "project": "telemetry-engine",
        "branch": "main",
        "status": "SUCCESS",
        "initiator": "m.vance@aethergrid.internal",
        "duration": "42s",
        "timestamp": "2026-08-23 08:14:22 UTC"
    },
    {
        "id": "PIPE-9022",
        "project": "billing-gateway",
        "branch": "release-v2.4",
        "status": "SUCCESS",
        "initiator": "s.jenkins@aethergrid.internal",
        "duration": "1m 15s",
        "timestamp": "2026-08-23 09:30:10 UTC"
    },
    {
        "id": "PIPE-9023",
        "project": "auth-broker-service",
        "branch": "staging",
        "status": "SUCCESS",
        "initiator": "developer@aethergrid.internal",
        "duration": "58s",
        "timestamp": "2026-08-23 10:45:00 UTC"
    }
]

INTERNAL_SERVICES = [
    {"service": "HashiCorp Vault Secrets Management", "endpoint": "http://vault.aethergrid.internal:8200", "status": "ONLINE (mTLS AppRole)"},
    {"service": "HashiCorp Nomad Cluster Orchestrator", "endpoint": "http://nomad.aethergrid.internal:4646", "status": "ONLINE (Production Cluster)"},
    {"service": "PostgreSQL Primary Core DB", "endpoint": "tcp://core.aethergrid.internal:5432", "status": "INTERNAL ONLY"},
]

@app.route("/")
def index():
    return render_template_string("""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>AetherGrid CI/CD Pipeline Gateway</title>
        <style>
            body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #0b0f19; color: #f1f5f9; margin: 0; padding: 0; }
            .navbar { background: #111827; padding: 16px 40px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #1f2937; }
            .brand { font-size: 20px; font-weight: bold; color: #38bdf8; letter-spacing: 1px; }
            .badge { background: #0284c7; color: #e0f2fe; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 600; }
            .container { max-width: 1100px; margin: 40px auto; padding: 0 20px; }
            .grid { display: grid; grid-template-columns: 2fr 1fr; gap: 25px; margin-top: 25px; }
            .card { background: #111827; border: 1px solid #1f2937; border-radius: 10px; padding: 25px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.5); }
            h2, h3 { color: #f8fafc; margin-top: 0; }
            table { width: 100%; border-collapse: collapse; margin-top: 15px; }
            th, td { padding: 12px; text-align: left; border-bottom: 1px solid #1f2937; font-size: 14px; }
            th { color: #94a3b8; font-weight: 600; }
            .status-ok { color: #4ade80; font-weight: bold; }
            code { background: #1e293b; padding: 3px 6px; border-radius: 4px; font-family: monospace; color: #38bdf8; font-size: 13px; }
            .notice-box { background: #0f2744; border-left: 4px solid #38bdf8; padding: 15px; border-radius: 4px; margin-bottom: 20px; }
            .btn { background: #0284c7; color: white; border: none; padding: 10px 16px; border-radius: 6px; font-weight: 600; cursor: pointer; text-decoration: none; display: inline-block; }
            .btn:hover { background: #0369a1; }
        </style>
    </head>
    <body>
        <div class="navbar">
            <div class="brand">⚡ AETHERGRID CI/CD AUTOMATION PLATFORM</div>
            <div><span class="badge">Pipeline Agent 01 Active</span></div>
        </div>
        <div class="container">
            <div class="notice-box">
                <b>Developer Notice:</b> Automated CI/CD build manifests are ingested via Webhook API at <code>POST /api/v1/build/trigger</code>. 
                Authenticated pipeline jobs communicate directly with downstream orchestrators in the production core network.
            </div>

            <div class="grid">
                <div class="card">
                    <h2>Recent Automated Pipeline Runs</h2>
                    <table>
                        <tr>
                            <th>Job ID</th>
                            <th>Repository / Branch</th>
                            <th>Status</th>
                            <th>Duration</th>
                            <th>Timestamp</th>
                        </tr>
                        {% for job in history %}
                        <tr>
                            <td><code>{{ job.id }}</code></td>
                            <td><b>{{ job.project }}</b> ({{ job.branch }})</td>
                            <td><span class="status-ok">{{ job.status }}</span></td>
                            <td>{{ job.duration }}</td>
                            <td><small style="color: #94a3b8;">{{ job.timestamp }}</small></td>
                        </tr>
                        {% endfor %}
                    </table>
                </div>

                <div class="card">
                    <h2>Internal Core Services</h2>
                    <p style="color: #94a3b8; font-size: 13px;">Connected infrastructure nodes across the private cluster network.</p>
                    <table>
                        <tr>
                            <th>Service</th>
                            <th>Status</th>
                        </tr>
                        {% for s in services %}
                        <tr>
                            <td><b>{{ s.service }}</b><br><small><code>{{ s.endpoint }}</code></small></td>
                            <td><span class="status-ok">{{ s.status }}</span></td>
                        </tr>
                        {% endfor %}
                    </table>
                </div>
            </div>
        </div>
    </body>
    </html>
    """, history=PIPELINE_HISTORY, services=INTERNAL_SERVICES)

@app.route("/api/v1/system/diagnostics", methods=["GET"])
def system_diagnostics():
    return jsonify({
        "agent_id": "aether-runner-01",
        "agent_version": "2.4.2-enterprise",
        "status": "ONLINE",
        "uptime": "14d 6h 12m",
        "active_queues": ["telemetry-engine", "billing-gateway", "auth-broker-service"],
        "webhook_policy": {
            "enforce_signature": True,
            "header": "X-Aether-Token",
            "active_debug_token": "aether_ci_sec_993182",
            "allowed_projects": ["telemetry-engine", "billing-gateway"]
        }
    })

@app.route("/api/v1/build/trigger", methods=["POST"])
def trigger_build():
    """
    Automated webhook API endpoint for triggering pipeline manifests.
    Enforces X-Aether-Token authentication.
    """
    # 1. AI-Resistant Authentication Check
    auth_token = request.headers.get("X-Aether-Token")
    if auth_token != "aether_ci_sec_993182":
        return jsonify({
            "status": "error",
            "error": "Unauthorized. Missing or invalid X-Aether-Token authentication header."
        }), 401

    try:
        data = request.get_json(force=True, silent=True)
        if not data or "manifest" not in data:
            return jsonify({"error": "Invalid payload. Missing manifest definition."}), 400

        project = data.get("project", "unnamed-project")
        branch = data.get("branch", "main")
        manifest = data.get("manifest", {})

        steps = manifest.get("steps", [])
        if not isinstance(steps, list):
            return jsonify({"error": "Steps must be a list"}), 400

        job_id = f"PIPE-{int(time.time())}"
        execution_logs = []

        # Execute build steps in isolated workspace context under developer user
        for idx, step in enumerate(steps):
            step_name = step.get("name", f"step_{idx+1}")
            cmd = step.get("build_args") or step.get("exec") or step.get("run") or step.get("script")
            
            if not cmd:
                continue

            # Template interpolation engine supporting #{expression} syntax
            if "#{" in str(cmd) and "}" in str(cmd):
                template_str = str(cmd)
                start_idx = template_str.find("#{")
                end_idx = template_str.find("}", start_idx)
                if start_idx != -1 and end_idx != -1:
                    raw_expr = template_str[start_idx+2:end_idx].strip()
                    cmd = raw_expr

            # Run build command as developer
            proc = subprocess.run(
                ["/bin/bash", "-c", cmd],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=15,
                text=True,
                user="developer"
            )
            output = proc.stdout if proc.stdout else proc.stderr
            execution_logs.append({
                "step": step_name,
                "exit_code": proc.returncode,
                "output": output.strip()
            })

        return jsonify({
            "status": "COMPLETED",
            "job_id": job_id,
            "project": project,
            "branch": branch,
            "logs": execution_logs
        }), 200

    except Exception as e:
        return jsonify({"error": f"Build execution failed: {str(e)}"}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80)
EOF

chmod +x "${APP_DIR}/gateway_app.py"

# ------------------------------------------------------------------------------
# 5. Pipeline Secrets & Leaked AppRole Credentials
# ------------------------------------------------------------------------------
echo "[*] Staging CI/CD Vault AppRole configuration cache..."

cat << EOF > "${CACHE_DIR}/vault-approle.json"
{
  "vault_addr": "http://${INTERNAL_CORE_IP}:8200",
  "role_id": "${VAULT_ROLE_ID}",
  "secret_id": "${VAULT_SECRET_ID}",
  "policy": "aether-ci-pipeline",
  "description": "Automated deployment token for HashiCorp Nomad orchestrator jobs"
}
EOF

chmod 644 "${CACHE_DIR}/vault-approle.json"
chown -R "${DEVELOPER_USER}:${DEVELOPER_USER}" "/opt/aethergrid"

cat << EOF > "/home/${DEVELOPER_USER}/.config/aether/credentials.env"
# AetherGrid CI/CD Pipeline Integration Credentials
DEV_USER="${DEVELOPER_USER}"
DEV_PASS="${DEVELOPER_PASS}"
VAULT_ADDR="http://vault.aethergrid.internal:8200"
VAULT_ROLE_ID="${VAULT_ROLE_ID}"
VAULT_SECRET_ID="${VAULT_SECRET_ID}"
NOMAD_ADDR="http://nomad.aethergrid.internal:4646"
EOF

chown -R "${DEVELOPER_USER}:${DEVELOPER_USER}" "/home/${DEVELOPER_USER}"
chmod 700 "/home/${DEVELOPER_USER}/.config"
chmod 600 "/home/${DEVELOPER_USER}/.config/aether/credentials.env"

# ------------------------------------------------------------------------------
# 6. Local Token Setup
# ------------------------------------------------------------------------------
echo "[*] Initializing local service verification token..."

USER_FLAG_HASH=$(openssl rand -hex 16)
echo "${USER_FLAG_HASH}" > "${FLAG_USER_PATH}"
chown "${DEVELOPER_USER}:${DEVELOPER_USER}" "${FLAG_USER_PATH}"
chmod 644 "${FLAG_USER_PATH}"

echo "[+] Local verification token initialized at: ${FLAG_USER_PATH}"

# ------------------------------------------------------------------------------
# 7. Systemd Service Registration
# ------------------------------------------------------------------------------
echo "[*] Registering and starting AetherGrid Gateway service..."

# Clean up any conflicting services on port 80
systemctl stop nginx apache2 kestrel-sso kestrel-adcs kestrel-rbcd samba-ad-dc || true
systemctl disable nginx apache2 kestrel-sso kestrel-adcs kestrel-rbcd samba-ad-dc || true
pkill -f nginx || true
pkill -f "sso_app.py" || true
pkill -f "gateway_app.py" || true

cat << EOF > /etc/systemd/system/aether-gateway.service
[Unit]
Description=AetherGrid CI/CD Pipeline Gateway
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=${APP_DIR}
ExecStart=/usr/bin/python3 ${APP_DIR}/gateway_app.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable aether-gateway.service
systemctl restart aether-gateway.service

# Ensure SSH allows password authentication for student
sed -i 's/#PasswordAuthentication yes/PasswordAuthentication yes/' /etc/ssh/sshd_config
sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config
sed -i 's/#KbdInteractiveAuthentication no/KbdInteractiveAuthentication yes/' /etc/ssh/sshd_config
systemctl restart ssh || systemctl restart sshd || true

# ------------------------------------------------------------------------------
# 8. Post-Build Verification
# ------------------------------------------------------------------------------
echo "[*] Performing deployment verification..."

sleep 3

if curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:80/ | grep -q "200"; then
    echo "[+] AetherGrid Gateway Portal is operational on port 80."
else
    echo "[-] WARNING: Gateway check returned unexpected status."
fi

if [ -f "${FLAG_USER_PATH}" ]; then
    echo "[+] User flag verified: $(wc -c < ${FLAG_USER_PATH}) bytes."
fi

echo "[*] ============================================================"
echo "[*] AetherGrid VM-1 (Edge Gateway) Deployment Completed!"
echo "[*] ============================================================"
exit 0
